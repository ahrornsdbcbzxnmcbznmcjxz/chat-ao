from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
import openai
from dotenv import load_dotenv
import os

# .env fayldan kalitni yuklash
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

app = FastAPI()

# Frontend bilan bog‘lanish uchun CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/ask")
async def ask_question(request: Request):
    data = await request.json()
    question = data.get("question", "")

    if not question:
        return {"error": "Savol yuborilmadi"}

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "Sen aqlli va foydali AI asistentsan."},
            {"role": "user", "content": question}
        ]
    )

    answer = response['choices'][0]['message']['content']
    return {"answer": answer}
